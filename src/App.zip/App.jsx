import "./App.css";

function App() {
  const name = "배용성";

  return (
    <div className="profile-card">
      {/* 프로필 이미지 */}
      <img
        src="https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNTEyMjVfNzEg%2FMDAxNzY2NjM0MDg1MDI2.TjZQlD5nkOrhW4dlYQPCItc1w8IDbYyppbZi_2JuU80g.TyZvqAds7uYhhAhOmW_s_QEmPWrmWjNoZ6NyAYBHYS0g.JPEG%2F900%25A3%25DFScreenshot%25A3%25DF20251225%25A3%25DF123700%25A3%25DFNAVER.jpg&type=a340"
        alt="프로필 사진"
        className="profile-img"
      />

      {/* 이름 (인라인 스타일 조건 충족) */}
      <h2 style={{ fontWeight: "bold", color: "blue" }}>{name}</h2>

      {/* 추가 정보 */}
      <p className="job">리액트 개발자</p>
      <p className="desc">사용자 경험을 중요하게 생각합니다.</p>

      {/* 버튼 */}
      <button className="btn">팔로우</button>

      {/* GitHub 링크 */}
      <a
        href="https://github.com/ybae247365/mypage/blob/main/index.html"
        target="_blank"
        rel="noopener noreferrer"
        className="link-btn"
      >
        GitHub 프로필 보기
      </a>
    </div>
  );
}

export default App;
