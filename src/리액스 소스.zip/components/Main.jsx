import React from "react";

function Main() {
  return (
    <main>
      <article>
        <h2>첫 번째 글</h2>
        <p>내용...</p>
      </article>
    </main>
  );
}

export default Main;
